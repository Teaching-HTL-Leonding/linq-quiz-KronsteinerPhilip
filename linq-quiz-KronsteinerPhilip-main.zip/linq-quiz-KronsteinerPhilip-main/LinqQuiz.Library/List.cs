﻿namespace LinqQuiz.Library
{
    internal class List
    {
        public List()
        {
        }
    }
}